<template>
    <div>ratings</div>
</template>

<script>
export default {}
</script>
