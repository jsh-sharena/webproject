<template>
    <div>Seller</div>
</template>

<script>
export default {}
</script>
