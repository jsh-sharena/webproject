# manage-platform-with-restful-api
flask搭建的后台管理界面，采用flask-restful实现REST风格的api，前端采用ajax方式获取数据
# Usage
* `python main.py`
* 访问127.0.0.1:5000即可

# 效果图
![](https://github.com/ioiogoo/manage-platform-with-restful-api/blob/master/demo.jpg)
